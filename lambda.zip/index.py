import json
import boto3
import base64

secret_name = "test-secret"
region_name = "ap-south-1"

session = boto3.session.Session()
client = session.client(
    service_name='secretsmanager',
    region_name=region_name
)
cached_secret = None

def lambda_handler(event, context):
    global cached_secret

    if cached_secret is None:
        response = client.get_secret_value(SecretId=secret_name)
        cached_secret = json.loads(response['SecretString'])['apps']['forms']['TEST_KEY']
        print("secrets fetched from secrets manager")
    else:
        print("secrets fetched from cache")
    return {
        'statusCode': 200,
        'body': json.dumps({'secret': cached_secret})
    }
